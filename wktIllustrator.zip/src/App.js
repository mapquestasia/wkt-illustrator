import "./App.css";
import { MapCanvas } from "./components/MapCanvas";

function App() {
  return (
    <div className="App">
      <MapCanvas />
    </div>
  );
}

export default App;
